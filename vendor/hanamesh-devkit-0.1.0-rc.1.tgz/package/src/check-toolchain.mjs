import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';

export function checkToolchain({root = process.cwd(), pins, compiler = true}) {
  const require = createRequire(resolve(root, 'package.json'));
  const actual = {node: process.versions.node,
    pnpm: execFileSync('pnpm', ['--version'], {cwd: root, encoding: 'utf8'}).trim()};
  if (compiler) actual.typescript = require('typescript/package.json').version;
  if (pins.nodeTypes) actual.nodeTypes = require('@types/node/package.json').version;
  for (const [name, expected] of Object.entries(pins)) {
    assert.equal(actual[name], expected, `TOOLCHAIN_MISMATCH ${name}`);
  }
  console.log(JSON.stringify({event: 'toolchain_verified', ...actual}));
  return actual;
}
