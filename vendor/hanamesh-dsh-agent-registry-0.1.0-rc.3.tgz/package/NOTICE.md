# Source and distribution notice

- Registry source: user-supplied research archive, R4, package originally named
  `@hanamesh/dsh-agent-registry@0.0.1`.
- Test-only Codex source: same archive, `@hanamesh/dsh-runtime-codex@0.0.1`.
- Exact original source file hashes and containing archive hash:
  `docs/provenance/source-manifest.json`.
- Original repository: `yzsnstotz/hanamesh`. The live connector returned 404;
  no source Git SHA has been invented. The archive has no Git history for it.
- No prototype LICENSE was found. `UNLICENSED` and `private: true` are safeguards,
  not a new claim to ownership or a legal determination about the original work.
- Public DSH packages are external peer/development dependencies. No upstream
  implementation is vendored, patched, republished or relicensed in this package.
- Research reports are historical evidence only. Their passing results are not
  counted as this candidate's passing results.
