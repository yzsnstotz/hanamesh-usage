# HanaMesh Runtime Registry

`@hanamesh/dsh-agent-registry@0.1.0-rc.2` · 独立仓库 `hanamesh-plugin-runtime-registry`

**交付状态：`DELIVERED`（等用户验收），不是 ACCEPTED。** rc.1 是在无 Node 24 / 固定 DSH / Codex 的环境下交付的候选；2026-09-12 回收判定在目标环境完成固定语义构建、原 G1 13 条真实门、G02 零上游改动、真实 profile 安装加载、真实 DSH 强杀与反序变异、四阶段真实 Codex 联验，全部记录在 `docs/acceptance/MATRIX.md` 末尾「回收判定记录」。下文「固定版本与本轮环境」一节是 rc.1 交付方的原始记录，按规矩保留。

## 本包做什么

在 DSH 公开 `AgentRegistry` 上做窄扩展，按明确 runtime 创建、按持久 binding 恢复；stock `agent-loop` 继续拥有原来的单 factory。不实现 Agent Loop、UI、ACP、新 Codex driver 或模型/认证转发。

源头是保存于 Library 的 R4 研究交付中的 `prototype/packages/hanamesh-runtime`，不是另造一个注册协议。原型原件、原 13 条测试及摘要在 `research-snapshot/`；原研究 Git commit 和许可证未能核实，见 `docs/provenance/source-manifest.json`。测试用 Codex 源码逐字保留在 `test-support/codex-driver/src/`，不是 MOD-07 发布物或本包的生产依赖。

## 已实现的关键修复

| 项目 | 行为 |
|---|---|
| 持久写入顺序 | 内存准备 → 预留 binding → build/setup → 提交 owner → 创建/刷新 DSH session → 发布。`ownerBeforeAuthority` 是两条生产创建路径共用的顺序边界。 |
| 失败与竞态 | 单个宿主内同 session 的 create/resume 互斥；失败只释放相同 txId 的 `reserving` 记录，绝不删除 `active` owner。 |
| 恢复路由 | missing、未完成、损坏、错配、driver 缺失一律拒绝；不能自动 native/adopt-native。现有 DSH session 缺少新 binding 时，也禁止通过 create 抢占身份。 |
| 输入与读取 | 校验完整记录；公开读取返回冻结快照；拒绝改变已预留身份；额外字段不被顺手写成凭据。 |
| 资源生命周期 | 处理中途取消、owner 卸载、异步 builder/持久句柄晚返回、幂等关闭；清理错误会被保留。 |
| 存储 | 插件状态只走公开 `dsh-storage-domain`；v3 采用 `single` 布局，每次写入完整记录；不向 session 写插件事件。 |
| 原接口 | `ctx.hanameshRuntimes.register/get/list`、`RuntimeDriver.createAgent/resume`、`DriverServices.publish`、`ctx.agents.create/resume/readBinding` 保持。新增错误类型可从包根导入。 |

### 边界必须保留

一个 profile / domain 只允许一个写入宿主进程。本实现没有把 domain 版本戳当作 CAS，也没有声称解决两个进程同时写同一个缓存域的问题。顺序冷恢复与并发共享 profile 是不同问题。

`reserving` 是可拒绝的未完成 owner；`active` 表示路由身份已提交，不表示 session 一定存在或 Agent 正在运行。提交之后的异常可能留下有 owner 的孤儿，不能在失败分支删掉该 owner。自动孤儿回收被关闭：尚未完成的活跃创建也可能暂时没有 session 文件。

本版本**不自动迁移 v1/v2 数据**。没有声明旧格式兼容；不能把旧 `per-record` 布局自动当成新 `single` 布局。只在全新隔离 profile 或经另行审核迁移的 profile 使用。旧记录可能因版本不符被拒绝，也可能因介质布局不同不被新域读取；两种情况都不得静默当成 native。

Driver 是受信任的同进程插件，不是恶意插件沙箱。driver 必须使用并返回 `services.publish` 的句柄，负责进入此方法前的外部进程/握手窗口，并响应传入取消信号。原 Codex 快照的该窗口、真实强杀后外部线程归属仍需真实运行验收，不能由本包的文件替身强杀测试代证。

## 固定版本与本轮环境

| 项目 | 产品基线 | 本轮实际 |
|---|---|---|
| DSH | `0.1.5-alpha.1` | 未安装，实际门 BLOCKED |
| 上游源码 | `5dda764ed3aa172535a7967b06ff95d9cbfe536a` | 已读取部分公开接口；没有完整 checkout 可核对 |
| Node | `24.13.1` | `22.16.0` / Linux |
| pnpm | `10.33.0` | 固定安装未完成 |
| TypeScript | `5.9.3` | 使用 `5.8.3` 做语法与独立声明输出；**非完整语义构建** |
| Codex | `0.153.4`, app-server v2 | 未安装 / 未使用任何模型额度 |

`pnpm-lock.yaml` 从原研究锁文件提取，移除了 workspace importer，保留上游解析结果与 integrity。当前无法联网做 frozen install，因此其完整安装验证仍待执行。

## 本地测试

```sh
# 有本地或全局 TypeScript 时可执行；该路径明确不是产品基线验收。
npm run test:offline
npm run test:fixture
npm run test:mutations
npm run check
```

本轮实际结果：**53 项 core/tooling/真实进程强杀（替身介质） + 43 项宿主/协议替身测试 = 96 项通过**。另外两种代码变异（去掉 owner 检查、放回 native fallback）均被已有断言抓住；X03 还实际反转生产顺序代码并强杀，正确暴露无主权威。

原始输出在 `docs/acceptance/*.tap`；不能把这些数当成 G01 的真实 13/13。`tests/fixtures/loader.mjs` 只用于显式 fixture 命令，真实门不会载入它。

## 固定版本构建与 G1 升级门

在具备固定 Node、pnpm 与依赖访问的环境中：

```sh
corepack pnpm@10.33.0 install --frozen-lockfile
npm run build
node tools/upgrade-gate.mjs --upstream=/absolute/path/to/clean/deepseek-harness
```

`build` 要求固定编译器并启用 `noEmitOnError`。没有有效语义构建记录时，正式 `pack:release` 会拒绝；随包附的 `.tgz` 是显式 `--candidate` 打出的预验收产物。

**每次升级 DSH，先在单独验证分支更新精确依赖与锁文件，再运行原 13 条门。** `--dsh-version=... --dsh-commit=... --node-version=...` 可以指定待测 pin；参数不会替你升级全局软件，也不能把未安装的版本视为已测试。

升级门会为状态新建独立临时目录，不使用个人 `~/.dsh`、不监听端口、更不会操作 3080。它记录缺依赖为 BLOCKED，以非零退出；没有“自动用 fixture 通过”的退路。G02 使用真实干净上游 git checkout 的全树前后哈希；静态无私有 import 不等于此门通过。

`tests/integration/g1-contract.test.mjs` 与原研究的 **13 条测试逐字一致**。`g1-regression.test.mjs` 中 RG6 改成拒绝自动 native adoption，RG9 改成不可变快照；完整旧版也保留，两个修订见 `docs/CHANGES.md`。该回归套件还需要测试 Codex 包；原真实 CLI 脚本也保留，但本轮没有执行。

## 安装与产品 profile

```sh
node tools/verify-artifacts.mjs
# 在隔离的 DSH profile 包目录内，而非个人配置中：
npm install --ignore-scripts --save-exact /absolute/path/to/artifacts/hanamesh-dsh-agent-registry-0.1.0-rc.1.tgz
```

将 `profile/cordis.patch.yml` 合入该隔离 profile 的 patch 层：**停用 stock `agent` 行，插入本包行，保留 stock `agent-loop` 行**。DSH loader 的 `name` 字段是守卫，不能靠原地改名替换服务。这是有意替换 `agents` 服务，不是声称“零装配代价”。真实 profile 加载 G03 尚未验证。

跨仓标准选用 **精确版本 + 自包含 tarball + SHA-256**；生产依赖禁止 `workspace:*` 或指向邻仓源码。下游记录 `artifacts/manifest.json` 的 digest，不能仅记录文件名。候选包还未 ACCEPTED，**不能据此解锁 MOD-07 / activity**。测试 Codex 快照中指向本 tarball 的相对位置只是随交付包携带的隔离测试定位，不是跨仓源代码依赖。

## Git 与交接

ZIP 含本次新建的独立本地 Git 仓库和 tag。未将附件文档仓的历史、未提交改动或个人配置混入这个仓库。远端未创建、未 push：本次 GitHub 连接可读取，但没有建仓/写入动作，运行环境也没有已授权的 gh 推送入口。

`tools/create-private-repo.sh` 只面向 `yzsnstotz/hanamesh-plugin-runtime-registry`，只建**私有仓库**，核对登录用户、干净工作树和空 remote；目标已存在就拒绝，不覆盖其他仓库。运行该脚本需要用户环境已有认证的 `gh`。

`handoff/hanamesh-docs.patch` 只修改原附件里 runtime-registry 的状态/阻塞/交接条目，添加对应 learning；保留其他模块的状态。应用时先在文档仓执行 `git apply --check`，存在并行修改冲突就人工合并这些条目，不覆盖整个 STATUS 文件。
