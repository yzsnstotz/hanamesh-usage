/** Narrow public AgentRegistry extension; the stock AgentLoop still owns its single factory. */
import type { Context } from '@deepseek-ai/cordis';
import { AgentRegistry, type AgentHandle, type CreateAgentOptions, type ResumeAgentOptions } from '@deepseek-ai/dsh-agent';
import type { SessionId } from '@deepseek-ai/dsh-session';
import { RuntimeBindingStore } from './binding-store.ts';
import { BindingUnusableError } from './binding-core.ts';
import { type RuntimeBinding, type RuntimeDriver } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        hanameshRuntimes: HanaMeshRuntimeRegistry;
    }
}
/** Missing ownership never permits an automatic runtime guess. */
export type UnboundSessionPolicy = 'refuse';
export interface HanaMeshRegistryConfig {
    readonly presetRuntimes?: Readonly<Record<string, string>>;
    readonly unboundSessions?: UnboundSessionPolicy;
}
export declare class HanaMeshRuntimeRegistry {
    private readonly ctx;
    private readonly drivers;
    constructor(ctx: Context);
    register(driver: RuntimeDriver): () => void;
    get(id: string): RuntimeDriver | undefined;
    list(): string[];
}
export declare class MissingRuntimeDriverError extends Error {
    readonly sessionId: SessionId;
    readonly runtime: string;
    constructor(sessionId: SessionId, runtime: string);
}
export declare class UnboundSessionError extends Error {
    readonly sessionId: SessionId;
    constructor(sessionId: SessionId);
}
export declare class SessionOperationInProgressError extends Error {
    readonly sessionId: SessionId;
    constructor(sessionId: SessionId);
}
export declare class HanaMeshAgentRegistry extends AgentRegistry {
    /**
     * The agent scope of an EXTERNAL runtime is minted from this service's
     * context (lifecycle.ts). Host code that runs inside that scope — the stock
     * session controller's `setup` (agent-preset mount, model selection) and any
     * agent-scoped plugin — resolves services through it, and Cordis only
     * resolves what an ancestor fiber injected. The upstream loop declares this
     * same list for the native agent scope; without it, every external create
     * through the real session controller fails with
     * `cannot get property "sessions" without inject` (found 2026-09-13 on the
     * first real-profile Codex session; the harness never passed a `setup`).
     */
    static inject: readonly string[];
    private readonly presetRuntimes;
    private readonly operations;
    readonly bindings: RuntimeBindingStore;
    constructor(ctx: Context, config?: HanaMeshRegistryConfig);
    private operation;
    private runtimeForCreate;
    /**
     * The stock session controller stamps EVERY create/resume with the host's
     * current default model selection (`agentDefaultModel.currentSelection()`),
     * even when the session is bound to an external runtime that has its own
     * model and auth (PRD FR-06: the host model picker is not forced on external
     * runtimes). That pair is the host filling in its own default, not a person
     * choosing a model for this runtime, so it is removed before dispatch. Any
     * OTHER provider/model — an explicit choice — still reaches the driver, whose
     * fail-closed conflict checks are unchanged.
     */
    private forExternal;
    private driverServices;
    create(options: CreateAgentOptions): Promise<AgentHandle>;
    resume(options: ResumeAgentOptions): Promise<AgentHandle>;
    readBinding(sessionId: SessionId): Promise<RuntimeBinding | undefined>;
}
export { BindingUnusableError };
export default HanaMeshAgentRegistry;
